SteelDig 课题三汇报配图

模型：gpt-image-2
调用方式：用户提供的 /Users/mac/Desktop/image-test/generate_image.py（API/CLI）
尺寸：1536×1024，quality=high
01_architecture：P04 四层架构
02_pipeline：P05 数据流水线（PPT 中使用裁剪版本）
03_curation：P14 校订重放

全部为机制示意图。统计数字由 PPT 可编辑文本承载。
prompts/ 下保存完整最终提示词，images/ 下为实际使用原图。
